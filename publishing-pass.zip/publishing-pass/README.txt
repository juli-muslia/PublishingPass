=== PublishingPass ===

Contact: https://julianmuslia.com
Tags: password, management, PublishingPass, publishing-group
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

PublishingPass is a Password management plugin developed for Publishing-Group.de




